<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$style = "default";
if(isset($_COOKIE['style'])){
    $style = $_COOKIE['style'];
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Langue</title>
    <link rel="stylesheet" href="<?php echo $style; ?>.css">
  </head>
  <body>
    <main>
        <h1>Welcome to My Website</h1>  
    </main>
  </body>
</html>
