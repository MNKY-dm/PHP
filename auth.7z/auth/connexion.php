<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if(isset($_POST['login']) && isset($_POST['password'])){
    if($_POST['login'] === "admin" && $_POST['password'] === "admin"){
        $_SESSION["role"] = "admin";
        echo "Auth succès";
    }
    else{
        echo "Erreur auth";
    }
}
else{
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Auth</title>
  </head>
  <body>
    <main>
        <h1>Auth</h1>  
    </main>
    <form action="" method="POST">
        <label for="login">Login:</label><br>
        <input type="text" id="login" name="login"><br>
        <label for="pass">Password:</label><br>
        <input type="password" id="pass" name="password"><br>
        <input type="submit"/>
    </form> 
  </body>
</html>
<?php
}