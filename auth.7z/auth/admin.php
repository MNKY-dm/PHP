<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if(isset($_SESSION["role"]) && $_SESSION["role"] === 'admin'){
	echo "Bienvenu Admin!";
}
else{
	echo "Erreur d'auth";
}