<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if(isset($_GET['langue'])){
    setcookie("langue", htmlspecialchars($_GET['langue']), time()+3600);
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Langue</title>
  </head>
  <body>
    <main>
        <h1>Langue</h1>  
    </main>
    <form action="" method="GET">
        <button type="submit" name="langue" value="FR">FR</button>
        <button type="submit" name="langue" value="EN">EN</button>
    </form> 
  </body>
</html>
