<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$langue = null;
if(isset($_COOKIE['langue'])){
	if($_COOKIE['langue'] === "FR"){
		$langue = parse_ini_file("FR.ini");
	}
	if($_COOKIE['langue'] === "EN"){
		$langue = parse_ini_file("EN.ini");
	}
}
// print_r($langue);

foreach ($langue as $key => $value) {
	echo $key.": ".$value."<br>";
}